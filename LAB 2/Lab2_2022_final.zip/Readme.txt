Registration changes:

On Seminar 1 we defined a more complex registration where users could add their pets with all their data. After some trys and due the complexity, we decided to create a simple registration form with
the user personal data and move the add pet functionality inside our app. 

As we will use this functinality later, we decided to let the Pet and PetManager classes inside the deliverable. Also, we have an unused js name oldRegister with our first concept idea.


